from django.shortcuts import render
import requests,os
from django.conf import settings
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse

# Create your views here.
def filesList(request):
    path = os.path.join(settings.MEDIA_ROOT, "ANON")
    files=os.listdir(path)   

    return render(request,'filelist.html',{"files":files})

import pydicom

def filedetails(request,filename):
    data = pydicom.dcmread(os.path.join(settings.MEDIA_ROOT, "ANON/"+filename))
    return HttpResponse(data)


    


