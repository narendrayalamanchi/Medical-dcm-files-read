from django.conf.urls import include,url
from . import views

urlpatterns = [
    url(r'^filesList/$', views.filesList, name='filesList'),
    url(r'^filedetails/(?P<filename>[0-32A-Za-z0-9.\-_]+)/$', views.filedetails, name='filedetails'),

]
